# MotionStudio 2D

A cloud-ready, procedural 2D motion graphics generator. It creates scenes using Canvas drawing code (not AI-generated images), captures frames with Playwright, and encodes a 1920x1080 MP4 with FFmpeg.

## Features
- Browser-based script editor; blank lines split the script into scenes.
- Procedural animated backgrounds, stars, hills, orbit diagrams, city silhouettes and chart bars.
- Animated title/body text, subtle camera zoom, vignette and scene fades.
- Optional voiceover audio muxed into the MP4.
- 16:9, 1920x1080, 24 or 30 FPS.
- Docker deployment for cloud hosting.

## Run locally
Requires Docker installed:

```bash
docker build -t motionstudio-2d .
docker run --rm -p 8080:8080 motionstudio-2d
```

Open `http://localhost:8080`.

Without Docker, install Node.js 20+, FFmpeg, and Playwright Chromium:

```bash
npm install
npx playwright install chromium
npm start
```

Open `http://localhost:8080`.

## Deploy to a cloud service
Use any Docker-compatible host (for example, Render, Railway, Fly.io, or a VPS):
1. Upload this folder to a Git repository.
2. Create a new web service from that repository.
3. Choose Docker as the runtime.
4. Set the service port to `8080` (or allow the platform's `PORT` environment variable).
5. Deploy, then open the service URL.

For longer videos, use a cloud instance with at least 2 CPU cores and 4 GB RAM. Rendering is CPU-intensive. The app limits exports to 30 scenes and 180 seconds per render. Temporary frames are deleted after a successful download.

## How to use
1. Paste narration into the script box. Separate scenes with a blank line.
2. Click **Create scenes from script**.
3. Preview the generated scenes.
4. Optionally upload a voiceover audio file.
5. Click **Render Full HD MP4** and wait for the download.

## Customizing animation
Edit `public/engine.js`. The `drawFrame()` function selects a scene and calls the visual functions. Add new visual functions (for example `drawMap`, `drawTimeline`, `drawBlueprint`) and select them through each scene's `visual` property. Current visuals: `orbit`, `city`, `bars`, `landscape`.

## Current limitations
- Script-to-scene splitting is paragraph-based, not semantic AI scene understanding.
- Voiceover is muxed as a single audio track; the app does not generate speech or synchronize words automatically.
- The built-in visuals are procedural motion graphics, not full character animation or a physics engine.
- A production deployment should add authentication, per-user job queues, storage limits, and persistent object storage before public use.
