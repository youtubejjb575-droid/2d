const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { chromium } = require('playwright');
const { spawn } = require('child_process');
const app = express();
const PORT = process.env.PORT || 8080;
const ROOT = __dirname;
const RENDER_DIR = path.join(ROOT, 'renders');
fs.mkdirSync(RENDER_DIR, { recursive: true });
const upload = multer({ dest: path.join(RENDER_DIR, 'uploads'), limits: { fileSize: 100 * 1024 * 1024 } });
app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(ROOT, 'public')));
app.get('/health', (_, res) => res.json({ ok: true }));

function run(command, args) {
  return new Promise((resolve, reject) => {
    const p = spawn(command, args);
    let err = '';
    p.stderr.on('data', d => err += d.toString());
    p.on('close', code => code === 0 ? resolve() : reject(new Error(err.slice(-3000) || `${command} exited ${code}`)));
  });
}

app.post('/api/render', upload.single('voiceover'), async (req, res) => {
  let browser;
  const job = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const framesDir = path.join(RENDER_DIR, `${job}-frames`);
  const silentVideo = path.join(RENDER_DIR, `${job}-silent.mp4`);
  const finalVideo = path.join(RENDER_DIR, `${job}.mp4`);
  try {
    const project = JSON.parse(req.body.project || '{}');
    const scenes = Array.isArray(project.scenes) ? project.scenes : [];
    const fps = Math.max(12, Math.min(30, Number(project.fps) || 30));
    const width = 1920, height = 1080;
    if (!scenes.length || scenes.length > 30) throw new Error('Project must contain 1–30 scenes.');
    const duration = scenes.reduce((sum, s) => sum + Math.max(2, Math.min(20, Number(s.duration) || 5)), 0);
    if (duration > 180) throw new Error('Maximum export duration is 180 seconds.');
    fs.mkdirSync(framesDir, { recursive: true });
    browser = await chromium.launch({ headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
    const page = await browser.newPage({ viewport: { width, height }, deviceScaleFactor: 1 });
    await page.goto(`http://127.0.0.1:${PORT}/renderer.html`, { waitUntil: 'networkidle' });
    await page.evaluate(p => window.setProject(p), { scenes, width, height });
    const totalFrames = Math.ceil(duration * fps);
    for (let i = 0; i < totalFrames; i++) {
      await page.evaluate(({ frame, fps }) => window.drawFrame(frame, fps), { frame: i, fps });
      await page.screenshot({ path: path.join(framesDir, `frame-${String(i).padStart(6, '0')}.png`) });
    }
    await browser.close(); browser = null;
    await run('ffmpeg', ['-y', '-framerate', String(fps), '-i', path.join(framesDir, 'frame-%06d.png'), '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '19', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', silentVideo]);
    if (req.file) {
      const audioPath = req.file.path;
      await run('ffmpeg', ['-y', '-i', silentVideo, '-i', audioPath, '-map', '0:v:0', '-map', '1:a:0', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-shortest', '-movflags', '+faststart', finalVideo]);
      fs.unlinkSync(audioPath);
    } else {
      fs.renameSync(silentVideo, finalVideo);
    }
    res.download(finalVideo, 'motionstudio-video.mp4', () => {
      fs.rmSync(framesDir, { recursive: true, force: true });
      fs.rmSync(finalVideo, { force: true });
      fs.rmSync(silentVideo, { force: true });
    });
  } catch (e) {
    if (browser) await browser.close().catch(() => {});
    fs.rmSync(framesDir, { recursive: true, force: true });
    fs.rmSync(silentVideo, { force: true });
    fs.rmSync(finalVideo, { force: true });
    res.status(500).json({ error: e.message || 'Render failed' });
  }
});
app.listen(PORT, '0.0.0.0', () => console.log(`MotionStudio 2D running on ${PORT}`));
