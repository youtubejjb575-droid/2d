(() => {
const canvas=document.getElementById('c'),ctx=canvas.getContext('2d');let project={scenes:[]};
const palettes=[['#101b35','#315b72','#f4c77a'],['#17152e','#684d76','#f0b67c'],['#0b2630','#286b68','#d4e8b2'],['#1d1b24','#76533d','#e9c48a']];
function hash(s){let h=0;for(let i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))|0;return Math.abs(h)}
function drawBackground(t,seed,p){const [a,b,c]=p;let g=ctx.createLinearGradient(0,0,0,1080);g.addColorStop(0,a);g.addColorStop(1,b);ctx.fillStyle=g;ctx.fillRect(0,0,1920,1080);
// atmospheric glow
let glow=ctx.createRadialGradient(1420+Math.sin(t*.35)*90,300,20,1420,350,850);glow.addColorStop(0,c+'66');glow.addColorStop(1,'#00000000');ctx.fillStyle=glow;ctx.fillRect(0,0,1920,1080);
// stars / dust
for(let i=0;i<95;i++){let x=(i*197+seed*13)%1920,y=(i*83+seed*7)%700;let alpha=.15+.35*(.5+.5*Math.sin(t*1.8+i));ctx.fillStyle=`rgba(255,255,255,${alpha})`;ctx.beginPath();ctx.arc(x,y,1.5+(i%3)*.5,0,Math.PI*2);ctx.fill()}
// layered hills
for(let layer=0;layer<3;layer++){ctx.beginPath();let base=760+layer*105;ctx.moveTo(0,1080);ctx.lineTo(0,base);for(let x=0;x<=1920;x+=80){let y=base-65*Math.sin(x*.003+seed+layer*2)-28*Math.sin(x*.009+layer+t*.08);ctx.lineTo(x,y)}ctx.lineTo(1920,1080);ctx.closePath();ctx.fillStyle=['#101b2b','#111d2a','#0b121e'][layer];ctx.fill()}
}
function drawOrbit(t,c){ctx.save();ctx.translate(1450,390);ctx.strokeStyle=c+'99';ctx.lineWidth=3;for(let i=0;i<4;i++){ctx.beginPath();ctx.ellipse(0,0,150+i*65,65+i*27,-.4+i*.25,0,Math.PI*2);ctx.stroke()}ctx.fillStyle=c;ctx.beginPath();ctx.arc(0,0,42,0,Math.PI*2);ctx.fill();for(let i=0;i<4;i++){let a=t*(.35+i*.13)+i*1.7;ctx.beginPath();ctx.arc(Math.cos(a)*(150+i*65),Math.sin(a)*(65+i*27),9+i,0,Math.PI*2);ctx.fillStyle=['#f5d58c','#9ad9cf','#e89d78','#b9b6ff'][i];ctx.fill()}ctx.restore()}
function drawBars(t,c){ctx.save();ctx.translate(1240,760);for(let i=0;i<7;i++){let h=100+((i*71)%240)+Math.sin(t*1.5+i)*25;ctx.fillStyle=c+'bb';ctx.fillRect(i*65,0,34,-h);ctx.fillStyle='#ffffff55';ctx.fillRect(i*65,-h,34,4)}ctx.restore()}
function drawCity(t,c,seed){ctx.save();for(let i=0;i<13;i++){let x=i*155-40+Math.sin(t*.3+i)*8,w=95+(i*17%55),h=180+(i*73+seed)%290;ctx.fillStyle=['#172c3d','#20384a','#263d4c'][i%3];ctx.fillRect(x,850-h,w,h);for(let yy=875-h;yy<830;yy+=34)for(let xx=x+15;xx<x+w-10;xx+=25){ctx.fillStyle=(Math.sin(t*2+i+xx)>.2)?'#e8c77d':'#6d8b91';ctx.fillRect(xx,yy,8,12)}}ctx.restore()}
function wrap(text,max){let words=(text||'').split(/\s+/),lines=[],line='';for(const w of words){let test=line?line+' '+w:w;if(ctx.measureText(test).width>max&&line){lines.push(line);line=w}else line=test}if(line)lines.push(line);return lines}
function drawText(scene,local,duration,seed){const title=scene.title||'A STORY UNFOLDS';const body=scene.text||'';const intro=Math.min(1,local*1.8);ctx.save();let slide=(1-Math.min(1,local*2))*55;ctx.globalAlpha=intro;ctx.translate(135,slide);
ctx.fillStyle='#9ce8ca';ctx.font='500 22px Arial';ctx.letterSpacing='5px';ctx.fillText(`CHAPTER ${String(seed+1).padStart(2,'0')}`,0,635);
ctx.fillStyle='#ffffff';ctx.font='bold 76px Arial';ctx.letterSpacing='-1px';let titleLines=wrap(title.toUpperCase(),1050);titleLines.slice(0,2).forEach((l,i)=>ctx.fillText(l,0,735+i*88));
ctx.fillStyle='#d3dce8';ctx.font='32px Arial';ctx.letterSpacing='0px';let lines=wrap(body,980);lines.slice(0,3).forEach((l,i)=>ctx.fillText(l,0,930+i*43));
ctx.restore();
// animated progress line
ctx.fillStyle='#ffffff24';ctx.fillRect(135,1010,1650,4);ctx.fillStyle='#9ce8ca';ctx.fillRect(135,1010,1650*Math.min(1,local/duration),4);
}
window.setProject=p=>{project=p};
window.drawFrame=(frame,fps)=>{let time=frame/fps,elapsed=0,index=0,scene=project.scenes[0];for(let i=0;i<project.scenes.length;i++){let d=Math.max(2,Number(project.scenes[i].duration)||5);if(time<elapsed+d){index=i;scene=project.scenes[i];break}elapsed+=d;index=i;scene=project.scenes[i]}
const duration=Math.max(2,Number(scene.duration)||5),local=time-elapsed,seed=hash(scene.title||scene.text||String(index)),palette=palettes[seed%palettes.length];ctx.save();let zoom=1+Math.min(.055,local/duration*.055);ctx.translate(960,540);ctx.scale(zoom,zoom);ctx.translate(-960,-540);drawBackground(time,seed,palette);const visual=(scene.visual||['orbit','city','bars','landscape'][index%4]);if(visual==='orbit')drawOrbit(time,palette[2]);else if(visual==='city')drawCity(time,palette[2],seed);else if(visual==='bars')drawBars(time,palette[2]);else drawOrbit(time*.7,palette[2]);ctx.restore();
// vignette
let v=ctx.createRadialGradient(960,540,300,960,540,1100);v.addColorStop(0,'#00000000');v.addColorStop(1,'#02050acc');ctx.fillStyle=v;ctx.fillRect(0,0,1920,1080);
// subtle transition fade at scene boundaries
let fade=Math.min(1,local/.45,(duration-local)/.45);ctx.fillStyle=`rgba(4,7,13,${1-Math.max(0,fade)})`;ctx.fillRect(0,0,1920,1080);drawText(scene,local,duration,index);};
})();
